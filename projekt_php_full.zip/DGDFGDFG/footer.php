<?php
// footer.php
?>
<hr>
<footer>
    <p>&copy; <?php echo date('Y'); ?> Shop Online. All rights reserved.</p>
</footer>
</body>
</html>

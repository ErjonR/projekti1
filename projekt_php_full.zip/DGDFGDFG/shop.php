<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nike</title>
    <link rel="stylesheet" href="shop.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>Nike</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="shop.php">Products</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
  <main>
    <section class="product-list">
      <div class="product">
        <img src="https://i5.walmartimages.com/seo/Nike-Sportswear-Club-Pullover-Fleece-Men-s-Hoodie-X-Small_0d3dc674-86fc-4de2-9586-63d8a05e5225.2fb8ff4c2ee625b5a6c3db9c5df6f8fe.jpeg" alt="Product 1" width="100px" height="100px">
        <h2>Produkti 1</h2>
        <p>$29.99</p>
        <button>Add to Cart</button>
      </div>

      <div class="product">
        <img src="https://i5.walmartimages.com/seo/Nike-Sportswear-Club-Pullover-Fleece-Men-s-Hoodie-X-Small_0d3dc674-86fc-4de2-9586-63d8a05e5225.2fb8ff4c2ee625b5a6c3db9c5df6f8fe.jpeg" alt="Product 2" width="100px" height="100px">
        <h2>Produkti 2</h2>
        <p>$49.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://i.pinimg.com/736x/76/1c/7a/761c7a1d550a39a88d6a22f544ff56a0.jpg" alt="Product 3" width="100px" height="100px">
        <h2>Produkti 3</h2>
        <p>$19.99</p>
        <button>Add to Cart</button>
      </div>
      <br><br>
      <div class="product">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbqvrCh88uC8egTlMEHhtBUs6n6w8ILTBWmA&s" alt="Product 1" width="100px" height="100px">
        <h2>Produkti 4</h2>
        <p>$29.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://i.pinimg.com/474x/26/f4/ec/26f4ecce5239a4f473f942cf89672202.jpg" alt="Product 2" width="100px" height="100px">
        <h2>Produkti 5</h2>
        <p>$49.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://shopcgx.com/cdn/shop/files/BV2654-410_MIDNIGHT_NAVY_-_1_800x.png?v=1707999997" alt="Product 3" width="100px" height="100px">
        <h2>Produkti 6</h2>
        <p>$19.99</p>
        <button>Add to Cart</button>
      </div>
      <br><br>
      <div class="product">
        <img src="https://nrml.ca/cdn/shop/files/DFNE.jpg?crop=center&height=1000&v=1717434216&width=1800" alt="Product 1" width="100px" height="100px">
        <h2>Produkti 7</h2>
        <p>$29.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://midwaysports.com/cdn/shop/files/NikeKid_sTeamClubPulloverHoodie_17_ba35a19a-a743-4b06-9f7b-2452aac877e8.png?v=1720861474" alt="Product 2" width="100px" height="100px">
        <h2>Produkti 8</h2>
        <p>$49.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://www.futbolemotion.com/imagesarticulos/218093/750/bota-nike-air-zoom-mercurial-superfly-9-academy-turf-nino-pink-foam-black-0.webp" alt="Product 3" width="100px" height="100px">
        <h2>Produkti 9</h2>
        <p>$19.99</p>
        <button>Add to Cart</button>
      </div>
      <br><br>
      <div class="product">
        <img src="https://images.stockx.com/images/Nike-Air-Max-Dawn-Pastel-W.jpg?fit=fill&bg=FFFFFF&w=1200&h=857&q=60&dpr=1&trim=color&updated_at=1678116988s" alt="Product 1" width="100px" height="100px">
        <h2>Produkti 10</h2>
        <p>$29.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://www.jdsports.gr/2749022-product_medium/nike-dunk-low-next-nature.jpg" alt="Product 2" width="100px" height="100px">
        <h2>Produkti 11</h2>
        <p>$49.99</p>
        <button>Add to Cart</button>
      </div>
<br><br>
      <div class="product">
        <img src="https://images.stockx.com/images/Nike-Air-Force-1-Low-Valentines-Day-2023-TD.jpg?fit=fill&bg=FFFFFF&w=480&h=320&q=60&dpr=1&trim=color&updated_at=1675077556" alt="Product 3">
        <h2>Produkti 12</h2>
        <p>$19.99</p>
        <button>Add to Cart</button>
      </div>
     <br><br>
     <div class="product">
      <img src="https://grailify.com/rails/active_storage/blobs/proxy/eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaHBBODRYQXc9PSIsImV4cCI6bnVsbCwicHVyIjoiYmxvYl9pZCJ9fQ==--ac87a7879f505d521561db025f539879a8a9b012/StockX-x-Grailify-50-scaled" alt="Product 1" width="100px" height="100px">
      <h2>Produkti 1</h2>
      <p>$29.99</p>
      <button>Add to Cart</button>
    </div>

    <div class="product">
      <img src="https://static.flexdog.com/flexdog-0/products/images/10a1388e-6010-4d8c-b531-0b952358435e_instyle_ai.png" alt="Product 2" width="100px" height="100px">
      <h2>Produkti 2</h2>
      <p>$49.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://i.pinimg.com/736x/d0/8e/56/d08e5649453bbf3e7f233dfdb2dde86b.jpg" alt="Product 3" width="100px" height="100px">
      <h2>Produkti 3</h2>
      <p>$19.99</p>
      <button>Add to Cart</button>
    </div>
    <br><br>
    <div class="product">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBcQTKt356tPSU81BkOEN7Isb7MMadPDeSnA&s" alt="Product 1" width="100px" height="100px">
      <h2>Produkti 4</h2>
      <p>$29.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://images.stockx.com/images/Nike-Mercurial-Vapor-360-Off-White-Product.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1680887313" alt="Product 2" width="100px" height="100px">
      <h2>Produkti 5</h2>
      <p>$49.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_NWSADNGhTKZVY2VabBysqFpe3Uyf1bwK9A&s" alt="Product 3" width="100px" height="100px">
      <h2>Produkti 6</h2>
      <p>$19.99</p>
      <button>Add to Cart</button>
    </div>
    <br><br>
    <div class="product">
      <img src="https://images.stockx.com/images/Nike-Mercurial-Superfly-10-Elite-FG-Blueprint-Pack-Product.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1721740392" alt="Product 1" width="100px" height="100px">
      <h2>Produkti 7</h2>
      <p>$29.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://images.stockx.com/images/Nike-Zoom-Mercurial-Vapor-15-Elite-KM-FG-Mbappe-Motivation-Pack.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1722890005" alt="Product 2" width="100px" height="100px">
      <h2>Produkti 8</h2>
      <p>$49.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://images.stockx.com/images/Nike-Vapor-Edge-Kyler-Murray-Dunk-Product.jpg?fit=fill&bg=FFFFFF&w=700&h=500&fm=webp&auto=compress&q=90&dpr=2&trim=color&updated_at=1700674501" alt="Product 3" width="100px" height="100px">
      <h2>Produkti 9</h2>
      <p>$19.99</p>
      <button>Add to Cart</button>
    </div>
    <br><br>
    <div class="product">
      <img src="https://s3.amazonaws.com/stockx-sneaker-analysis/wp-content/uploads/2020/07/Nike-Mercurial-Superfly-VI-Elite-CR7-FG-Chapter-6-Special-Edition-e1595517487380.jpg" alt="Product 1" width="100px" height="100px">
      <h2>Produkti 10</h2>
      <p>$29.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://images.stockx.com/images/Nike-Vapor-Edge-Kobe-6-SE-Grinch-Product.jpg?fit=fill&bg=FFFFFF&w=1200&h=857&q=60&dpr=1&trim=color&updated_at=1733412786" alt="Product 2" width="100px" height="100px">
      <h2>Produkti 11</h2>
      <p>$49.99</p>
      <button>Add to Cart</button>
    </div>
<br><br>
    <div class="product">
      <img src="https://images.stockx.com/360/Nike-Zoom-Mercurial-Superfly-9-Academy-MG-Luminous-Pack/Images/Nike-Zoom-Mercurial-Superfly-9-Academy-MG-Luminous-Pack/Lv2/img01.jpg" alt="Product 3">
      <h2>Produkti 12</h2>
      <p>$19.99</p>
      <button>Add to Cart</button>
    </div>
   <br><br>
    </section>
  </main>
  <footer>
    <div class="footer-container">
        <!-- Footer Column 1: Company Info -->
        <div class="footer-column">
            <h3>Company</h3>
            <ul>
                <li><a href="about.php">About Us</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Press</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>

        <!-- Footer Column 2: Quick Links -->
        <div class="footer-column">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="#">Refund Policy</a></li>
            </ul>
        </div>

        <!-- Footer Column 3: Newsletter Subscription -->
        <div class="footer-column">
            <h3>Newsletter</h3>
            <p>Subscribe to our newsletter for the latest updates and offers.</p>
            <form action="contact.html">
                <input type="email" placeholder="Enter your email" required>
                <button type="submit">Subscribe</button>
            </form>
        </div>

        <!-- Footer Column 4: Social Media Links -->
        <div class="footer-column">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href="#" class="social-icon"><img src="https://i.pinimg.com/736x/84/68/5b/84685ba9637a951591040426a46da70f.jpg" alt="Facebook"></a>
                <a href="#" class="social-icon"><img src="twitter-icon.png" alt="Twitter"></a>
                <a href="https://www.instagram.com/end.mehmeti/?next=%2F" class="social-icon"><img src="https://i.pinimg.com/originals/e5/d3/76/e5d376b99ef839fe38135eb1ffc68189.jpg" alt="Instagram"></a>
                <a href="#" class="social-icon"><img src="linkedin-icon.png" alt="LinkedIn"></a>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; Endrit Mehmeti,Nuart Ramadani,Amir Kuleta,Erjon Jashari. All Rights Reserved.</p>
    </div>
</footer>

<script src="shop.js"></script>
</body>
</html>
</body>
</html>
<?php include 'footer.php'; ?>